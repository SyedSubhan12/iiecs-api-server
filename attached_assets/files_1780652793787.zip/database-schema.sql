-- ========================================
-- IIECS-101 ATTENDANCE SYSTEM
-- PostgreSQL / Supabase Database Schema
-- ========================================

-- ========================================
-- 1. STUDENTS TABLE
-- ========================================

CREATE TABLE IF NOT EXISTS students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  id_number VARCHAR(50) UNIQUE NOT NULL,
  batch VARCHAR(100) NOT NULL,
  qr_code_data TEXT NOT NULL,
  profile_photo_url TEXT,
  phone VARCHAR(20),
  address TEXT,
  cnic VARCHAR(15),
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  enrollment_date TIMESTAMP DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_students_email ON students(email);
CREATE INDEX idx_students_id_number ON students(id_number);
CREATE INDEX idx_students_batch ON students(batch);
CREATE INDEX idx_students_status ON students(status);

-- ========================================
-- 2. ATTENDANCE TABLE
-- ========================================

CREATE TABLE IF NOT EXISTS attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  attendance_date DATE NOT NULL,
  check_in_time TIMESTAMP NOT NULL,
  check_out_time TIMESTAMP,
  status VARCHAR(20) NOT NULL DEFAULT 'present' CHECK (status IN ('present', 'absent', 'late', 'excused')),
  marked_by UUID REFERENCES admins(id) ON DELETE SET NULL,
  remarks TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(student_id, attendance_date)
);

CREATE INDEX idx_attendance_student_id ON attendance(student_id);
CREATE INDEX idx_attendance_date ON attendance(attendance_date);
CREATE INDEX idx_attendance_status ON attendance(status);
CREATE INDEX idx_attendance_student_date ON attendance(student_id, attendance_date);

-- ========================================
-- 3. PAYMENTS TABLE
-- ========================================

CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  amount DECIMAL(10, 2) NOT NULL,
  description VARCHAR(255) DEFAULT 'Course Fee - IIECS-101',
  due_date DATE,
  paid_date DATE,
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'overdue', 'partial')),
  payment_method VARCHAR(50),
  reference_number VARCHAR(100),
  payment_proof_url TEXT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_payments_student_id ON payments(student_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_due_date ON payments(due_date);

-- ========================================
-- 4. INVOICES TABLE
-- ========================================

CREATE TABLE IF NOT EXISTS invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  payment_id UUID REFERENCES payments(id) ON DELETE SET NULL,
  invoice_number VARCHAR(50) UNIQUE NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  issued_date TIMESTAMP DEFAULT NOW(),
  due_date DATE,
  status VARCHAR(20) NOT NULL DEFAULT 'unpaid' CHECK (status IN ('unpaid', 'paid', 'overdue', 'cancelled')),
  pdf_url TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_invoices_student_id ON invoices(student_id);
CREATE INDEX idx_invoices_invoice_number ON invoices(invoice_number);
CREATE INDEX idx_invoices_status ON invoices(status);

-- ========================================
-- 5. ADMINS TABLE
-- ========================================

CREATE TABLE IF NOT EXISTS admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'admin' CHECK (role IN ('admin', 'instructor', 'coordinator')),
  permissions TEXT[],
  last_login TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_admins_email ON admins(email);
CREATE INDEX idx_admins_role ON admins(role);

-- ========================================
-- 6. ATTENDANCE SETTINGS TABLE
-- ========================================

CREATE TABLE IF NOT EXISTS attendance_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch VARCHAR(100) NOT NULL,
  month VARCHAR(20),
  year INTEGER,
  total_working_days INTEGER,
  minimum_attendance_percentage DECIMAL(5, 2) DEFAULT 75,
  created_by UUID REFERENCES admins(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(batch, month, year)
);

-- ========================================
-- 7. AUDIT LOG TABLE
-- ========================================

CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  action VARCHAR(255) NOT NULL,
  entity_type VARCHAR(50),
  entity_id UUID,
  admin_id UUID REFERENCES admins(id) ON DELETE SET NULL,
  old_values JSONB,
  new_values JSONB,
  ip_address VARCHAR(45),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_admin ON audit_logs(admin_id);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at);

-- ========================================
-- 8. VIEWS FOR REPORTING
-- ========================================

-- Monthly Attendance Summary
CREATE OR REPLACE VIEW attendance_summary AS
SELECT
  s.id,
  s.full_name,
  s.id_number,
  s.email,
  s.batch,
  DATE_TRUNC('month', a.attendance_date)::DATE AS month,
  COUNT(CASE WHEN a.status = 'present' THEN 1 END) AS days_present,
  COUNT(CASE WHEN a.status = 'absent' THEN 1 END) AS days_absent,
  COUNT(CASE WHEN a.status = 'late' THEN 1 END) AS days_late,
  COUNT(*) AS total_days,
  ROUND(
    (COUNT(CASE WHEN a.status = 'present' THEN 1 END)::DECIMAL / COUNT(*)) * 100,
    2
  ) AS attendance_percentage
FROM students s
LEFT JOIN attendance a ON s.id = a.student_id
GROUP BY s.id, s.full_name, s.id_number, s.email, s.batch, DATE_TRUNC('month', a.attendance_date);

-- Payment Status Summary
CREATE OR REPLACE VIEW payment_summary AS
SELECT
  s.id,
  s.full_name,
  s.id_number,
  s.email,
  s.batch,
  COUNT(CASE WHEN p.status = 'pending' THEN 1 END) AS pending_payments,
  COUNT(CASE WHEN p.status = 'paid' THEN 1 END) AS paid_payments,
  COUNT(CASE WHEN p.status = 'overdue' THEN 1 END) AS overdue_payments,
  COALESCE(SUM(CASE WHEN p.status IN ('pending', 'overdue') THEN p.amount ELSE 0 END), 0) AS total_due,
  COALESCE(SUM(CASE WHEN p.status = 'paid' THEN p.amount ELSE 0 END), 0) AS total_paid
FROM students s
LEFT JOIN payments p ON s.id = p.student_id
GROUP BY s.id, s.full_name, s.id_number, s.email, s.batch;

-- Student Progress View
CREATE OR REPLACE VIEW student_progress AS
SELECT
  s.id,
  s.full_name,
  s.id_number,
  s.email,
  s.batch,
  s.enrollment_date,
  COALESCE(
    ROUND(
      (COUNT(a.id) FILTER (WHERE a.status = 'present')::DECIMAL / NULLIF(COUNT(a.id), 0)) * 100,
      2
    ),
    0
  ) AS overall_attendance_percentage,
  COUNT(a.id) AS total_attendance_records,
  COALESCE(SUM(CASE WHEN p.status = 'paid' THEN p.amount ELSE 0 END), 0) AS total_paid,
  COALESCE(SUM(CASE WHEN p.status IN ('pending', 'overdue') THEN p.amount ELSE 0 END), 0) AS total_pending
FROM students s
LEFT JOIN attendance a ON s.id = a.student_id
LEFT JOIN payments p ON s.id = p.student_id
GROUP BY s.id, s.full_name, s.id_number, s.email, s.batch, s.enrollment_date;

-- ========================================
-- 9. FUNCTIONS & TRIGGERS
-- ========================================

-- Function to update invoice status based on payment
CREATE OR REPLACE FUNCTION update_invoice_on_payment()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'paid' AND OLD.status != 'paid' THEN
    UPDATE invoices
    SET status = 'paid',
        updated_at = NOW()
    WHERE payment_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for payment status updates
CREATE OR REPLACE TRIGGER payment_status_trigger
AFTER UPDATE ON payments
FOR EACH ROW
EXECUTE FUNCTION update_invoice_on_payment();

-- Function to generate invoice number
CREATE OR REPLACE FUNCTION generate_invoice_number(student_id UUID)
RETURNS VARCHAR AS $$
DECLARE
  invoice_num VARCHAR;
BEGIN
  SELECT 'INV-' || TO_CHAR(NOW(), 'YYYYMM') || '-' || LPAD(COUNT(*)::TEXT, 4, '0')
  INTO invoice_num
  FROM invoices
  WHERE invoices.student_id = generate_invoice_number.student_id
    AND DATE_TRUNC('month', invoices.created_at) = DATE_TRUNC('month', NOW());
  
  RETURN COALESCE(invoice_num, 'INV-' || TO_CHAR(NOW(), 'YYYYMM') || '-0001');
END;
$$ LANGUAGE plpgsql;

-- Function to update student updated_at timestamp
CREATE OR REPLACE FUNCTION update_student_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER student_update_timestamp
BEFORE UPDATE ON students
FOR EACH ROW
EXECUTE FUNCTION update_student_timestamp();

-- ========================================
-- 10. SAMPLE DATA (For Testing)
-- ========================================

-- Insert Admin Users
INSERT INTO admins (email, full_name, role, is_active) VALUES
('admin@iiecs.edu', 'System Administrator', 'admin', TRUE),
('teacher@iiecs.edu', 'Course Instructor', 'instructor', TRUE)
ON CONFLICT (email) DO NOTHING;

-- Insert Sample Students
INSERT INTO students (email, full_name, id_number, batch, qr_code_data, phone, status) VALUES
('safi@student.iiecs.edu', 'Safi ullah Abbasi Asif', 'IIECS-014', 'Batch B - C/C++ Algorithms', 
 '{"id":"1","name":"Safi ullah Abbasi Asif","email":"safi@student.iiecs.edu","idNumber":"IIECS-014","batch":"Batch B","enrollmentDate":"2024-01-15"}',
 '+92-300-1234567', 'active'),
('student2@student.iiecs.edu', 'Ahmed Hassan', 'IIECS-015', 'Batch B - C/C++ Algorithms',
 '{"id":"2","name":"Ahmed Hassan","email":"student2@student.iiecs.edu","idNumber":"IIECS-015","batch":"Batch B","enrollmentDate":"2024-01-15"}',
 '+92-300-7654321', 'active'),
('student3@student.iiecs.edu', 'Fatima Khan', 'IIECS-016', 'Batch B - C/C++ Algorithms',
 '{"id":"3","name":"Fatima Khan","email":"student3@student.iiecs.edu","idNumber":"IIECS-016","batch":"Batch B","enrollmentDate":"2024-01-15"}',
 '+92-300-9876543', 'active')
ON CONFLICT (email) DO NOTHING;

-- Insert Sample Payments
INSERT INTO payments (student_id, amount, due_date, status, description) 
SELECT id, 50000, '2024-02-15', 'pending', 'Course Fee - IIECS-101'
FROM students
WHERE id_number LIKE 'IIECS-%'
ON CONFLICT DO NOTHING;

-- ========================================
-- 11. ROW LEVEL SECURITY (RLS)
-- ========================================

-- Enable RLS on all tables
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Students can only see their own records
CREATE POLICY "Students view own data" ON students
  FOR SELECT
  USING (email = current_user);

-- Students can update their own profile
CREATE POLICY "Students update own profile" ON students
  FOR UPDATE
  USING (email = current_user);

-- Admins can view all student data
CREATE POLICY "Admins view all students" ON students
  FOR SELECT
  USING (current_user = 'admin@iiecs.edu' OR current_user = 'teacher@iiecs.edu');

-- Students can view their own attendance
CREATE POLICY "Students view own attendance" ON attendance
  FOR SELECT
  USING (student_id IN (
    SELECT id FROM students WHERE email = current_user
  ));

-- Admins can view all attendance
CREATE POLICY "Admins view all attendance" ON attendance
  FOR ALL
  USING (current_user = 'admin@iiecs.edu' OR current_user = 'teacher@iiecs.edu');

-- Students can view their own payments
CREATE POLICY "Students view own payments" ON payments
  FOR SELECT
  USING (student_id IN (
    SELECT id FROM students WHERE email = current_user
  ));

-- Students can view their own invoices
CREATE POLICY "Students view own invoices" ON invoices
  FOR SELECT
  USING (student_id IN (
    SELECT id FROM students WHERE email = current_user
  ));

-- ========================================
-- 12. STORAGE BUCKETS (For Files)
-- ========================================

-- Create storage buckets for:
-- 1. Student ID Cards
-- 2. Payment Proofs
-- 3. Generated Invoices
-- 4. Profile Photos

-- Use Supabase UI to create buckets:
-- Bucket: id-cards (public)
-- Bucket: invoices (private)
-- Bucket: payment-proofs (private)
-- Bucket: profile-photos (private)

-- ========================================
-- 13. DATABASE PERMISSIONS
-- ========================================

-- Grant necessary permissions to authenticated users
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- For specific operations
GRANT EXECUTE ON FUNCTION generate_invoice_number(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION update_student_timestamp() TO authenticated;

-- ========================================
-- QUICK REFERENCE QUERIES
-- ========================================

-- Get today's attendance
SELECT s.full_name, a.status, a.check_in_time
FROM attendance a
JOIN students s ON a.student_id = s.id
WHERE a.attendance_date = CURRENT_DATE
ORDER BY a.check_in_time DESC;

-- Get pending payments for a student
SELECT *
FROM payments
WHERE student_id = '...' AND status IN ('pending', 'overdue')
ORDER BY due_date ASC;

-- Get attendance percentage for each student (current month)
SELECT *
FROM attendance_summary
WHERE month = DATE_TRUNC('month', CURRENT_DATE)::DATE
ORDER BY attendance_percentage DESC;

-- Get students with payment dues
SELECT *
FROM payment_summary
WHERE total_due > 0
ORDER BY total_due DESC;

-- Get overall student progress
SELECT *
FROM student_progress
ORDER BY overall_attendance_percentage DESC;

-- Create a new invoice
INSERT INTO invoices (student_id, amount, due_date, status, invoice_number)
VALUES (
  (SELECT id FROM students WHERE id_number = 'IIECS-014'),
  50000,
  CURRENT_DATE + INTERVAL '15 days',
  'unpaid',
  generate_invoice_number((SELECT id FROM students WHERE id_number = 'IIECS-014'))
);

-- ========================================
-- MAINTENANCE QUERIES
-- ========================================

-- Update overdue payments
UPDATE payments
SET status = 'overdue'
WHERE status = 'pending'
  AND due_date < CURRENT_DATE;

-- Mark overdue invoices
UPDATE invoices
SET status = 'overdue'
WHERE status = 'unpaid'
  AND due_date < CURRENT_DATE;

-- Archive old records (e.g., older than 2 years)
-- DELETE FROM attendance
-- WHERE attendance_date < CURRENT_DATE - INTERVAL '2 years';

-- Get database statistics
SELECT
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname || '.' || tablename)) AS size
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname || '.' || tablename) DESC;
