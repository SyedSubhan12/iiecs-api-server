// FILE: app/layout.tsx
import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'IIECS-101 | Attendance & Invoice System',
  description: 'Manage attendance and invoices with QR code scanning',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="bg-gray-50 text-gray-900">{children}</body>
    </html>
  )
}

// ---

// FILE: app/page.tsx
import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#001F3F] via-[#003366] to-[#004080]">
      <div className="text-center space-y-8 px-6">
        {/* Logo */}
        <div className="inline-block">
          <div className="text-6xl font-bold text-white mb-2">IIECS</div>
          <div className="text-2xl text-[#FFC107] tracking-widest font-semibold">-101</div>
          <p className="text-white/60 text-sm mt-2">AI • Automation • Innovation</p>
        </div>

        {/* Title */}
        <div className="space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold text-white">
            Attendance & Invoice System
          </h1>
          <p className="text-white/80 max-w-2xl mx-auto text-lg">
            Streamlined QR-based attendance tracking and automated invoice generation for IIECS-101 students
          </p>
        </div>

        {/* CTA */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/login"
            className="px-8 py-3 bg-[#FFC107] text-[#001F3F] rounded-xl font-bold hover:bg-white transition transform hover:scale-105"
          >
            Login to Dashboard
          </Link>
          <Link
            href="/login"
            className="px-8 py-3 bg-white/20 text-white rounded-xl font-bold hover:bg-white/30 backdrop-blur border border-white/30 transition"
          >
            Learn More
          </Link>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 mt-12 max-w-4xl">
          <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-6 text-white">
            <div className="text-4xl mb-3">📱</div>
            <h3 className="font-bold mb-2">QR Scanner</h3>
            <p className="text-white/70 text-sm">Scan ID cards for instant attendance</p>
          </div>
          <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-6 text-white">
            <div className="text-4xl mb-3">📊</div>
            <h3 className="font-bold mb-2">Real-time Reports</h3>
            <p className="text-white/70 text-sm">Track progress and payment status</p>
          </div>
          <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-6 text-white">
            <div className="text-4xl mb-3">🧾</div>
            <h3 className="font-bold mb-2">Auto Invoices</h3>
            <p className="text-white/70 text-sm">Generate and download payment receipts</p>
          </div>
        </div>
      </div>
    </div>
  )
}

// ---

// FILE: app/dashboard/admin/layout.tsx
'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const [email, setEmail] = useState('')

  useEffect(() => {
    const storedEmail = localStorage.getItem('iiecs_email')
    const adminEmails = (process.env.NEXT_PUBLIC_ADMIN_EMAILS || '').split(',')

    if (!storedEmail || !adminEmails.includes(storedEmail)) {
      router.push('/login')
    } else {
      setEmail(storedEmail)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem('iiecs_session')
    localStorage.removeItem('iiecs_email')
    router.push('/login')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-screen w-64 bg-[#001F3F] text-white p-6 shadow-2xl">
        <div className="mb-8">
          <div className="text-3xl font-bold mb-1">IIECS</div>
          <div className="text-[#FFC107] text-lg font-semibold">-101</div>
          <p className="text-white/60 text-xs mt-2">Admin Dashboard</p>
        </div>

        <nav className="space-y-2">
          {[
            { href: '/dashboard/admin', label: '📊 Dashboard', icon: '📊' },
            { href: '/dashboard/admin/scanner', label: '📱 Scanner', icon: '📱' },
            { href: '/dashboard/admin/attendance', label: '✓ Attendance', icon: '✓' },
            { href: '/dashboard/admin/payments', label: '💳 Payments', icon: '💳' },
            { href: '/dashboard/admin/reports', label: '📈 Reports', icon: '📈' },
          ].map(item => (
            <Link
              key={item.href}
              href={item.href}
              className="block px-4 py-3 rounded-lg hover:bg-white/10 transition"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="absolute bottom-6 left-6 right-6 space-y-4">
          <div className="text-xs text-white/60 border-t border-white/20 pt-4">
            <p className="mb-2">Logged in as:</p>
            <p className="font-mono text-[#FFC107]">{email}</p>
          </div>
          <button
            onClick={handleLogout}
            className="w-full bg-red-500 hover:bg-red-600 text-white py-2 rounded-lg font-semibold transition"
          >
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="ml-64">
        <div className="p-8">
          {children}
        </div>
      </div>
    </div>
  )
}

// ---

// FILE: app/dashboard/admin/page.tsx
'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface DashboardStats {
  totalStudents: number
  presentToday: number
  absentToday: number
  pendingPayments: number
  totalPaymentsDue: number
  attendancePercentage: number
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalStudents: 0,
    presentToday: 0,
    absentToday: 0,
    pendingPayments: 0,
    totalPaymentsDue: 0,
    attendancePercentage: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDashboardStats()
  }, [])

  const loadDashboardStats = async () => {
    try {
      const today = new Date().toISOString().split('T')[0]

      // Total students
      const { count: studentCount } = await supabase
        .from('students')
        .select('*', { count: 'exact', head: true })

      // Attendance today
      const { data: todayAttendance } = await supabase
        .from('attendance')
        .select('*')
        .eq('attendance_date', today)

      // Pending payments
      const { data: payments } = await supabase
        .from('payments')
        .select('*')
        .eq('status', 'pending')

      const totalPaymentsDue = payments?.reduce((sum, p) => sum + p.amount, 0) || 0

      setStats({
        totalStudents: studentCount || 0,
        presentToday: todayAttendance?.filter(a => a.status === 'present').length || 0,
        absentToday: todayAttendance?.filter(a => a.status === 'absent').length || 0,
        pendingPayments: payments?.length || 0,
        totalPaymentsDue,
        attendancePercentage: studentCount ? Math.round(((todayAttendance?.filter(a => a.status === 'present').length || 0) / studentCount) * 100) : 0,
      })
    } catch (err) {
      console.error('Error loading stats:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="text-center py-12">Loading dashboard...</div>
  }

  const statCards = [
    { label: 'Total Students', value: stats.totalStudents, color: 'bg-blue-500', icon: '👥' },
    { label: 'Present Today', value: stats.presentToday, color: 'bg-green-500', icon: '✓' },
    { label: 'Absent Today', value: stats.absentToday, color: 'bg-red-500', icon: '✗' },
    { label: 'Attendance %', value: `${stats.attendancePercentage}%`, color: 'bg-purple-500', icon: '📊' },
    { label: 'Pending Payments', value: stats.pendingPayments, color: 'bg-yellow-500', icon: '💳' },
    { label: 'Total Due', value: `Rs. ${stats.totalPaymentsDue.toFixed(0)}`, color: 'bg-orange-500', icon: '💰' },
  ]

  return (
    <div className="space-y-6">
      <h1 className="text-4xl font-bold text-[#001F3F]">Dashboard</h1>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-3 gap-6">
        {statCards.map((card, idx) => (
          <div
            key={idx}
            className={`${card.color} text-white rounded-2xl p-6 shadow-lg transform hover:scale-105 transition`}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm font-medium">{card.label}</p>
                <p className="text-3xl font-bold mt-2">{card.value}</p>
              </div>
              <div className="text-5xl opacity-20">{card.icon}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-[#001F3F] mb-6">Quick Actions</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <a
            href="/dashboard/admin/scanner"
            className="p-6 border-2 border-[#001F3F] rounded-xl hover:bg-[#001F3F] hover:text-white transition text-center font-semibold"
          >
            📱 Scan QR & Mark Attendance
          </a>
          <a
            href="/dashboard/admin/payments"
            className="p-6 border-2 border-[#001F3F] rounded-xl hover:bg-[#001F3F] hover:text-white transition text-center font-semibold"
          >
            💳 Update Payment Status
          </a>
          <a
            href="/dashboard/admin/attendance"
            className="p-6 border-2 border-[#001F3F] rounded-xl hover:bg-[#001F3F] hover:text-white transition text-center font-semibold"
          >
            ✓ View Attendance Records
          </a>
          <a
            href="/dashboard/admin/reports"
            className="p-6 border-2 border-[#001F3F] rounded-xl hover:bg-[#001F3F] hover:text-white transition text-center font-semibold"
          >
            📈 Generate Reports
          </a>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-[#001F3F] mb-4">System Status</h2>
        <div className="space-y-3">
          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <p>System running normally</p>
          </div>
          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <p>QR scanner connected and ready</p>
          </div>
          <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <p>{stats.pendingPayments} payment(s) awaiting action</p>
          </div>
        </div>
      </div>
    </div>
  )
}

// ---

// FILE: app/dashboard/student/layout.tsx
'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

export default function StudentLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const [email, setEmail] = useState('')

  useEffect(() => {
    const storedEmail = localStorage.getItem('iiecs_email')
    const adminEmails = (process.env.NEXT_PUBLIC_ADMIN_EMAILS || '').split(',')

    if (!storedEmail) {
      router.push('/login')
    } else if (adminEmails.includes(storedEmail)) {
      router.push('/dashboard/admin')
    } else {
      setEmail(storedEmail)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem('iiecs_session')
    localStorage.removeItem('iiecs_email')
    router.push('/login')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#001F3F] to-[#003366] text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold">IIECS</div>
            <div className="text-[#FFC107] text-sm font-semibold">-101</div>
          </div>

          <nav className="hidden md:flex gap-6">
            {[
              { href: '/dashboard/student', label: 'Dashboard' },
              { href: '/dashboard/student/profile', label: 'Profile' },
              { href: '/dashboard/student/attendance', label: 'Attendance' },
              { href: '/dashboard/student/payments', label: 'Invoices' },
            ].map(item => (
              <a
                key={item.href}
                href={item.href}
                className="hover:text-[#FFC107] transition"
              >
                {item.label}
              </a>
            ))}
          </nav>

          <button
            onClick={handleLogout}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-semibold transition"
          >
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {children}
      </div>
    </div>
  )
}

// ---

// FILE: styles/globals.css
@import 'tailwindcss/base';
@import 'tailwindcss/components';
@import 'tailwindcss/utilities';

:root {
  --color-navy: #001F3F;
  --color-navy-dark: #003366;
  --color-gold: #FFC107;
  --color-success: #28a745;
  --color-danger: #dc3545;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* Custom scrollbar */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
  background: var(--color-navy);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: var(--color-navy-dark);
}

/* Animations */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-fade-in {
  animation: fadeIn 0.3s ease-out;
}

/* Loading spinner */
.spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid var(--color-navy);
  border-radius: 50%;
  width: 40px;
  height: 40px;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

// ---

// FILE: .env.local
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
SUPABASE_SERVICE_KEY=your_service_key_here

NEXT_PUBLIC_ADMIN_EMAILS=admin@iiecs.edu,teacher@iiecs.edu
NEXT_PUBLIC_STUDENT_EMAILS_PATTERN=@student.iiecs.edu

NEXT_PUBLIC_APP_NAME=IIECS-101
NEXT_PUBLIC_BATCH_NAME=Batch B - C/C++ Algorithms

// ---

// FILE: tailwind.config.ts
import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#001F3F',
          dark: '#003366',
          light: '#004080',
        },
        gold: '#FFC107',
      },
      boxShadow: {
        'lg': '0 10px 25px rgba(0, 31, 63, 0.15)',
      },
    },
  },
  plugins: [],
}

export default config

// ---

// FILE: next.config.js
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    unoptimized: false,
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.supabase.co',
      },
    ],
  },
  experimental: {
    appDir: true,
  },
}

module.exports = nextConfig
