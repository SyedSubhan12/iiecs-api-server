# IIECS-101 Attendance System - Supabase Setup Guide

## Step 1: Supabase Project Setup

### 1.1 Create Supabase Account & Project

1. Go to [supabase.com](https://supabase.com)
2. Sign up or login
3. Create new project:
   - Name: `iiecs-101-system`
   - Database Password: (save this)
   - Region: Select closest to Karachi (Singapore or India)
   - Pricing: Free or Pro

4. Wait for project initialization (~2-3 minutes)

### 1.2 Get Credentials

Navigate to **Settings → API**
```
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
SUPABASE_SERVICE_KEY=eyJhbGc... (save for backend)
```

Copy these to `.env.local`

---

## Step 2: Database Schema

### 2.1 Import Schema

1. In Supabase, go to **SQL Editor**
2. Click **New Query**
3. Paste entire contents of `database-schema.sql`
4. Click **Run**

Wait for all queries to complete (check status)

### 2.2 Verify Tables Created

Go to **Table Editor** and verify these tables exist:
- ✓ `students`
- ✓ `attendance`
- ✓ `payments`
- ✓ `invoices`
- ✓ `admins`
- ✓ `attendance_settings`
- ✓ `audit_logs`

---

## Step 3: Authentication Setup

### 3.1 Configure Email Auth (Optional)

1. Go to **Authentication → Providers**
2. Email provider is enabled by default
3. Go to **Email Templates** to customize confirmation emails

### 3.2 Create Admin & Student Records

Go to **SQL Editor** and run:

```sql
-- Insert admins
INSERT INTO admins (email, full_name, role, is_active) VALUES
('admin@iiecs.edu', 'System Administrator', 'admin', TRUE),
('teacher@iiecs.edu', 'Course Instructor', 'instructor', TRUE);

-- Insert sample students
INSERT INTO students (
  email, full_name, id_number, batch, qr_code_data, phone, status
) VALUES
('safi@student.iiecs.edu', 'Safi ullah Abbasi Asif', 'IIECS-014', 
 'Batch B - C/C++ Algorithms',
 '{"id":"1","name":"Safi ullah Abbasi Asif","email":"safi@student.iiecs.edu","idNumber":"IIECS-014","batch":"Batch B","enrollmentDate":"2024-01-15"}',
 '+92-300-1234567', 'active'),
('student2@student.iiecs.edu', 'Ahmed Hassan', 'IIECS-015',
 'Batch B - C/C++ Algorithms',
 '{"id":"2","name":"Ahmed Hassan","email":"student2@student.iiecs.edu","idNumber":"IIECS-015","batch":"Batch B","enrollmentDate":"2024-01-15"}',
 '+92-300-7654321', 'active');
```

---

## Step 4: Storage Buckets

### 4.1 Create Buckets

1. Go to **Storage → Buckets**
2. Create 4 new buckets:

| Bucket Name | Public | Purpose |
|---|---|---|
| `id-cards` | ✓ Yes | Student ID card PDFs |
| `invoices` | ✗ No | Generated invoices |
| `profile-photos` | ✗ No | Student photos |
| `payment-proofs` | ✗ No | Payment receipts |

### 4.2 Set Bucket Policies

For `id-cards` (public access):
```sql
-- Anyone can view
CREATE POLICY "Public Read" ON storage.objects
  FOR SELECT USING (bucket_id = 'id-cards');

-- Authenticated users can upload
CREATE POLICY "Authenticated Upload" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'id-cards' AND auth.role() = 'authenticated'
  );
```

---

## Step 5: Local Development Setup

### 5.1 Create Next.js Project

```bash
# Create new Next.js app
npx create-next-app@latest iiecs-101-system --typescript --tailwind

cd iiecs-101-system

# Install dependencies
npm install \
  @supabase/supabase-js \
  html5-qrcode \
  qrcode \
  jspdf \
  date-fns \
  zustand

# Copy files from implementation-guide.ts
# Place them in appropriate directories
```

### 5.2 Configure Environment

Create `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
SUPABASE_SERVICE_KEY=eyJhbGc...

NEXT_PUBLIC_ADMIN_EMAILS=admin@iiecs.edu,teacher@iiecs.edu
NEXT_PUBLIC_STUDENT_EMAILS_PATTERN=@student.iiecs.edu

NEXT_PUBLIC_APP_NAME=IIECS-101
NEXT_PUBLIC_BATCH_NAME=Batch B - C/C++ Algorithms
```

### 5.3 Run Development Server

```bash
npm run dev
```

Open http://localhost:3000

**Test Login:**
- Admin: `admin@iiecs.edu` / `password`
- Student: `safi@student.iiecs.edu` / `password`

---

## Step 6: Deployment to Vercel

### 6.1 Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourusername/iiecs-101-system
git push -u origin main
```

### 6.2 Deploy to Vercel

1. Go to [vercel.com](https://vercel.com)
2. Click **New Project**
3. Import your GitHub repo
4. Add environment variables:
   ```
   NEXT_PUBLIC_SUPABASE_URL=...
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   SUPABASE_SERVICE_KEY=...
   NEXT_PUBLIC_ADMIN_EMAILS=...
   ```
5. Click **Deploy**

### 6.3 Configure Supabase Auth

1. In Supabase → **Settings → Authentication**
2. Go to **Authorized URLs**
3. Add your Vercel domain:
   ```
   https://iiecs-101-system.vercel.app
   https://iiecs-101-system-*.vercel.app
   ```

---

## Step 7: QR Code Generation

### 7.1 Generate QR Codes for Students

For each student, generate QR code containing JSON:

```json
{
  "id": "1",
  "name": "Safi ullah Abbasi Asif",
  "email": "safi@student.iiecs.edu",
  "idNumber": "IIECS-014",
  "batch": "Batch B",
  "enrollmentDate": "2024-01-15"
}
```

Use a QR code generator or the provided `lib/qr-generator.ts`:

```typescript
import { generateQRCodeImage } from '@/lib/qr-generator'

const qrData = {
  id: '1',
  name: 'Safi ullah Abbasi Asif',
  email: 'safi@student.iiecs.edu',
  idNumber: 'IIECS-014',
  batch: 'Batch B',
  enrollmentDate: '2024-01-15'
}

const qrImage = await generateQRCodeImage(JSON.stringify(qrData))
// Use qrImage to display or download
```

### 7.2 Print ID Cards

1. Create ID card design (mockup provided in design assets)
2. Include student photo + name + ID + QR code
3. Print in color on cardstock
4. Laminate for durability

---

## Database Queries Reference

### Mark Attendance for Today

```sql
INSERT INTO attendance (student_id, attendance_date, check_in_time, status, marked_by)
SELECT 
  s.id,
  CURRENT_DATE,
  CURRENT_TIMESTAMP,
  'present',
  (SELECT id FROM admins WHERE email = 'admin@iiecs.edu')
FROM students
WHERE s.id_number = 'IIECS-014';
```

### Get Student Attendance Percentage

```sql
SELECT 
  s.full_name,
  s.id_number,
  COUNT(CASE WHEN a.status = 'present' THEN 1 END) AS present_days,
  COUNT(*) AS total_days,
  ROUND((COUNT(CASE WHEN a.status = 'present' THEN 1 END)::DECIMAL / COUNT(*)) * 100, 2) AS percentage
FROM students s
LEFT JOIN attendance a ON s.id = a.student_id
WHERE EXTRACT(MONTH FROM a.attendance_date) = EXTRACT(MONTH FROM NOW())
GROUP BY s.id, s.full_name, s.id_number;
```

### Get Pending Payments

```sql
SELECT 
  s.full_name,
  s.id_number,
  p.amount,
  p.due_date,
  CURRENT_DATE - p.due_date AS days_overdue
FROM payments p
JOIN students s ON p.student_id = s.id
WHERE p.status IN ('pending', 'overdue')
ORDER BY p.due_date ASC;
```

### Generate Monthly Report

```sql
SELECT * FROM attendance_summary
WHERE month = DATE_TRUNC('month', CURRENT_DATE)::DATE
ORDER BY attendance_percentage DESC;
```

---

## API Endpoints Quick Reference

### Authentication
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `GET /api/auth/verify` - Verify session

### Student APIs
- `GET /api/students/profile` - Get student profile
- `GET /api/students/[id]/attendance` - Get attendance records
- `GET /api/students/[id]/payments` - Get payment history
- `GET /api/invoices/[id]/download` - Download invoice PDF

### Admin APIs
- `POST /api/attendance/scan` - Validate QR code
- `POST /api/attendance/mark` - Mark attendance
- `GET /api/attendance/report` - Get attendance report
- `PATCH /api/payments/[id]/update` - Update payment status
- `POST /api/invoices/generate` - Generate invoice

---

## Troubleshooting

### Issue: "Relation does not exist" error

**Solution:** Make sure all SQL schema has been executed. Re-run database-schema.sql

### Issue: QR scanner not working

**Solution:** 
- Check browser permissions for camera access
- Ensure HTTPS (required for camera access)
- Test with a sample QR code

### Issue: Storage bucket files not accessible

**Solution:**
- Check bucket is marked as public
- Verify storage policies are configured
- Check file permissions in bucket details

### Issue: Vercel deployment fails

**Solution:**
- Verify all environment variables are set
- Check Supabase project is active
- Ensure GitHub repo is public or connected properly

---

## Monitoring & Maintenance

### Regular Tasks

**Daily:**
- Check for failed attendance scans
- Monitor payment reminders

**Weekly:**
- Review attendance trends
- Check for pending payments

**Monthly:**
- Generate attendance reports
- Generate invoices for new billing cycle
- Archive old records

### Database Backups

Supabase automatically backs up data. To manually backup:

1. Go to **Settings → Backups**
2. Click **Create backup**
3. Download for local storage

---

## Security Checklist

- [ ] Supabase project created
- [ ] Environment variables secured (.env.local not in git)
- [ ] Email authentication configured
- [ ] Row Level Security (RLS) enabled
- [ ] Storage buckets configured
- [ ] Admin emails hardcoded in ENV
- [ ] HTTPS enforced (Vercel default)
- [ ] Regular backups enabled
- [ ] Audit logs being recorded

---

## Performance Optimization

### Database Indexes

All major queries have indexes created:
```sql
-- Already created in schema:
CREATE INDEX idx_attendance_student_date ON attendance(student_id, attendance_date);
CREATE INDEX idx_students_email ON students(email);
CREATE INDEX idx_payments_status ON payments(status);
```

### Caching Strategy

Implement client-side caching:
```typescript
// Use Zustand for state management
import create from 'zustand'

const useStudentStore = create((set) => ({
  student: null,
  setStudent: (student) => set({ student }),
  // ...
}))
```

---

## Scaling for Production

As you grow beyond 1000 students:

1. **Enable Supabase Pro** for increased limits
2. **Implement Connection Pooling** via PgBouncer
3. **Add Caching Layer** (Redis)
4. **Optimize Queries** with EXPLAIN ANALYZE
5. **Monitor Performance** with Supabase Analytics

---

## Support & Resources

- Supabase Docs: https://supabase.com/docs
- Next.js Docs: https://nextjs.org/docs
- PostgreSQL Docs: https://www.postgresql.org/docs/
- QR Code Docs: https://davidshimjs.github.io/qrcodejs/

---

**Ready to launch!** Your IIECS-101 Attendance System is production-ready.
