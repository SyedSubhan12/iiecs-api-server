# IIECS-101 Attendance & Invoice System

## Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│           Next.js 14 (App Router)                   │
├─────────────────────────────────────────────────────┤
│  ┌──────────────────┐  ┌──────────────────┐       │
│  │  Auth System     │  │  QR Scanner      │       │
│  │  (Email-based)   │  │  (html5-qrcode)  │       │
│  └──────────────────┘  └──────────────────┘       │
│                                                     │
│  ┌──────────────────────────────────────┐         │
│  │  Student Dashboard                   │         │
│  │  - Profile                           │         │
│  │  - Download ID Card / Invoice        │         │
│  │  - Check Progress                    │         │
│  └──────────────────────────────────────┘         │
│                                                     │
│  ┌──────────────────────────────────────┐         │
│  │  Admin Dashboard                     │         │
│  │  - QR Scanner                        │         │
│  │  - Attendance Management             │         │
│  │  - Payment Status                    │         │
│  │  - Reports & Analytics               │         │
│  └──────────────────────────────────────┘         │
├─────────────────────────────────────────────────────┤
│  Supabase (PostgreSQL + Auth + Storage)            │
├─────────────────────────────────────────────────────┤
│  Students │ Attendance │ Invoices │ Payments       │
└─────────────────────────────────────────────────────┘
```

---

## 1. DATABASE SCHEMA (PostgreSQL / Supabase)

```sql
-- Students Table
CREATE TABLE students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  id_number VARCHAR(50) UNIQUE NOT NULL,
  batch VARCHAR(100) NOT NULL,
  qr_code_data TEXT NOT NULL,
  profile_photo_url TEXT,
  phone VARCHAR(20),
  address TEXT,
  cnic VARCHAR(15),
  status VARCHAR(20) DEFAULT 'active',
  enrollment_date TIMESTAMP DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Attendance Table
CREATE TABLE attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  attendance_date DATE NOT NULL,
  check_in_time TIMESTAMP NOT NULL,
  check_out_time TIMESTAMP,
  status VARCHAR(20) DEFAULT 'present',
  marked_by UUID REFERENCES admins(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_attendance_student_date ON attendance(student_id, attendance_date);

-- Payments Table
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  amount DECIMAL(10, 2) NOT NULL,
  due_date DATE,
  paid_date DATE,
  status VARCHAR(20) DEFAULT 'pending',
  payment_method VARCHAR(50),
  reference_number VARCHAR(100),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Invoices Table
CREATE TABLE invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  payment_id UUID REFERENCES payments(id),
  invoice_number VARCHAR(50) UNIQUE NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  issued_date TIMESTAMP DEFAULT NOW(),
  due_date DATE,
  status VARCHAR(20) DEFAULT 'unpaid',
  pdf_url TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Admins Table
CREATE TABLE admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Attendance Settings Table
CREATE TABLE attendance_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID NOT NULL REFERENCES admins(id),
  month VARCHAR(20),
  year INTEGER,
  total_working_days INTEGER,
  minimum_attendance_percentage DECIMAL(5, 2) DEFAULT 75,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes
CREATE INDEX idx_students_email ON students(email);
CREATE INDEX idx_students_id_number ON students(id_number);
CREATE INDEX idx_attendance_date ON attendance(attendance_date);
CREATE INDEX idx_payments_student_id ON payments(student_id);
CREATE INDEX idx_invoices_student_id ON invoices(student_id);
CREATE INDEX idx_admins_email ON admins(email);
```

---

## 2. NEXT.JS PROJECT STRUCTURE

```
iiecs-101-system/
├── .env.local
├── app/
│   ├── layout.tsx
│   ├── page.tsx (Landing)
│   ├── login/
│   │   └── page.tsx
│   ├── api/
│   │   ├── auth/
│   │   │   ├── login/route.ts
│   │   │   ├── logout/route.ts
│   │   │   └── verify/route.ts
│   │   ├── attendance/
│   │   │   ├── scan/route.ts
│   │   │   ├── mark/route.ts
│   │   │   └── history/route.ts
│   │   ├── students/
│   │   │   ├── [id]/route.ts
│   │   │   ├── profile/route.ts
│   │   │   └── progress/route.ts
│   │   ├── payments/
│   │   │   ├── [id]/route.ts
│   │   │   └── update/route.ts
│   │   ├── invoices/
│   │   │   ├── [id]/route.ts
│   │   │   ├── generate/route.ts
│   │   │   └── download/route.ts
│   │   └── admin/
│   │       ├── students/route.ts
│   │       ├── attendance-report/route.ts
│   │       └── payments/route.ts
│   ├── dashboard/
│   │   ├── student/
│   │   │   ├── layout.tsx
│   │   │   ├── page.tsx
│   │   │   ├── profile/page.tsx
│   │   │   ├── attendance/page.tsx
│   │   │   ├── payments/page.tsx
│   │   │   └── downloads/page.tsx
│   │   └── admin/
│   │       ├── layout.tsx
│   │       ├── page.tsx
│   │       ├── scanner/page.tsx
│   │       ├── attendance/page.tsx
│   │       ├── payments/page.tsx
│   │       └── reports/page.tsx
├── components/
│   ├── auth/
│   │   ├── LoginForm.tsx
│   │   └── ProtectedRoute.tsx
│   ├── scanner/
│   │   └── QRScanner.tsx
│   ├── ui/
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── Modal.tsx
│   │   ├── Tabs.tsx
│   │   └── DataTable.tsx
│   └── dashboard/
│       ├── StudentNav.tsx
│       ├── AdminNav.tsx
│       ├── AttendanceChart.tsx
│       └── PaymentStatus.tsx
├── lib/
│   ├── supabase.ts
│   ├── auth.ts
│   ├── qr-generator.ts
│   ├── invoice-generator.ts
│   └── utils.ts
├── styles/
│   └── globals.css
├── public/
│   ├── logo.svg
│   └── assets/
└── package.json
```

---

## 3. KEY IMPLEMENTATION FILES

### 3.1 Environment Variables (.env.local)

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_KEY=your_service_key

# Hardcoded credentials
NEXT_PUBLIC_ADMIN_EMAILS=admin@iiecs.edu,teacher@iiecs.edu
NEXT_PUBLIC_STUDENT_EMAILS_PATTERN=@student.iiecs.edu

# Application
NEXT_PUBLIC_APP_NAME=IIECS-101
NEXT_PUBLIC_BATCH_NAME=Batch B - C/C++ Algorithms
```

### 3.2 lib/supabase.ts

```typescript
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseKey)

export type Student = {
  id: string
  email: string
  full_name: string
  id_number: string
  batch: string
  qr_code_data: string
  profile_photo_url?: string
  status: string
  enrollment_date: string
}

export type Attendance = {
  id: string
  student_id: string
  attendance_date: string
  check_in_time: string
  check_out_time?: string
  status: string
  marked_by?: string
}

export type Payment = {
  id: string
  student_id: string
  amount: number
  due_date?: string
  paid_date?: string
  status: 'pending' | 'paid' | 'overdue'
  payment_method?: string
}

export type Invoice = {
  id: string
  student_id: string
  payment_id?: string
  invoice_number: string
  amount: number
  issued_date: string
  due_date?: string
  status: 'unpaid' | 'paid'
  pdf_url?: string
}
```

### 3.3 lib/qr-generator.ts

```typescript
import QRCode from 'qrcode'

export interface QRCodeData {
  id: string
  name: string
  email: string
  idNumber: string
  batch: string
  enrollmentDate: string
}

export const generateQRCodeData = (student: QRCodeData): string => {
  return JSON.stringify({
    ...student,
    timestamp: new Date().toISOString(),
  })
}

export const generateQRCodeImage = async (data: string): Promise<string> => {
  try {
    return await QRCode.toDataURL(data, {
      errorCorrectionLevel: 'H',
      type: 'image/png',
      quality: 0.95,
      margin: 1,
      width: 300,
      color: {
        dark: '#001F3F', // IIECS Navy
        light: '#FFFFFF',
      },
    })
  } catch (error) {
    console.error('QR Code generation failed:', error)
    throw error
  }
}

export const parseQRCodeData = (qrData: string): QRCodeData => {
  return JSON.parse(qrData)
}
```

### 3.4 lib/invoice-generator.ts

```typescript
import { jsPDF } from 'jspdf'
import { Invoice, Student, Payment } from './supabase'

export const generateInvoicePDF = async (
  invoice: Invoice,
  student: Student,
  payment: Payment
): Promise<Blob> => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  })

  // Colors (IIECS brand)
  const navyBlue = [0, 31, 63]
  const gold = [255, 193, 7]

  // Header
  doc.setFillColor(...navyBlue)
  doc.rect(0, 0, 210, 30, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFontSize(24)
  doc.text('IIECS-101', 20, 20)
  doc.setFontSize(10)
  doc.text('Training Program', 20, 27)

  // Reset text color
  doc.setTextColor(0, 0, 0)

  // Invoice Details
  doc.setFontSize(16)
  doc.text('INVOICE', 20, 45)
  doc.setFontSize(10)
  doc.text(`Invoice #: ${invoice.invoice_number}`, 20, 55)
  doc.text(`Date: ${new Date(invoice.issued_date).toLocaleDateString()}`, 20, 63)
  doc.text(`Due Date: ${new Date(invoice.due_date || '').toLocaleDateString()}`, 20, 71)

  // Student Info
  doc.setFontSize(12)
  doc.text('Bill To:', 20, 85)
  doc.setFontSize(10)
  doc.text(student.full_name, 20, 93)
  doc.text(`Email: ${student.email}`, 20, 101)
  doc.text(`Student ID: ${student.id_number}`, 20, 109)
  doc.text(`Batch: ${student.batch}`, 20, 117)

  // Invoice Table
  const tableTop = 135
  doc.setFillColor(...navyBlue)
  doc.setTextColor(255, 255, 255)
  doc.text('Description', 20, tableTop)
  doc.text('Amount', 170, tableTop)

  doc.setTextColor(0, 0, 0)
  doc.setFillColor(240, 240, 240)
  doc.text('Course Fee - IIECS-101', 20, tableTop + 15)
  doc.text(`Rs. ${invoice.amount.toFixed(2)}`, 170, tableTop + 15)

  // Total
  doc.setFillColor(...navyBlue)
  doc.setTextColor(255, 255, 255)
  doc.rect(20, tableTop + 30, 170, 10, 'F')
  doc.text('Total Due:', 20, tableTop + 37)
  doc.text(`Rs. ${invoice.amount.toFixed(2)}`, 170, tableTop + 37)

  // Status
  doc.setTextColor(0, 0, 0)
  doc.setFontSize(10)
  const statusColor = invoice.status === 'paid' ? [0, 128, 0] : [255, 0, 0]
  doc.setTextColor(...statusColor)
  doc.text(`Status: ${invoice.status.toUpperCase()}`, 20, tableTop + 55)

  // Footer
  doc.setTextColor(100, 100, 100)
  doc.setFontSize(8)
  doc.text('IIECS-101 Training Program | AI • Automation • Innovation', 20, 270)
  doc.text('Please retain this invoice for your records.', 20, 276)

  return doc.output('blob')
}
```

### 3.5 app/login/page.tsx

```typescript
'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'

const adminEmails = process.env.NEXT_PUBLIC_ADMIN_EMAILS?.split(',') || []

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()

  const isAdmin = adminEmails.includes(email)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      // In production, use proper Supabase auth
      // For demo: hardcoded validation
      if (!email || !password) {
        throw new Error('Email and password required')
      }

      // Store session
      const sessionData = {
        email,
        role: isAdmin ? 'admin' : 'student',
        loginTime: new Date().toISOString(),
      }

      localStorage.setItem('iiecs_session', JSON.stringify(sessionData))
      localStorage.setItem('iiecs_email', email)

      // Redirect based on role
      if (isAdmin) {
        router.push('/dashboard/admin')
      } else {
        router.push('/dashboard/student')
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#001F3F] to-[#003366]">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-block mb-4">
            <div className="text-4xl font-bold text-white">IIECS</div>
            <div className="text-sm text-[#FFC107] tracking-widest">-101</div>
          </div>
          <p className="text-white/60 text-sm">Attendance & Invoice System</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h2 className="text-2xl font-bold text-[#001F3F] mb-6">Login</h2>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FFC107] focus:border-transparent"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FFC107] focus:border-transparent"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-[#001F3F] to-[#003366] text-white py-2 rounded-lg font-semibold hover:opacity-90 transition disabled:opacity-50"
            >
              {loading ? 'Logging in...' : 'Login'}
            </button>
          </form>

          {/* Test Credentials */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg text-xs text-gray-600">
            <p className="font-semibold mb-2">Test Credentials:</p>
            <p className="mb-1"><strong>Admin:</strong> admin@iiecs.edu / password</p>
            <p><strong>Student:</strong> student@student.iiecs.edu / password</p>
          </div>
        </div>
      </div>
    </div>
  )
}
```

### 3.6 components/scanner/QRScanner.tsx

```typescript
'use client'

import { useEffect, useRef, useState } from 'react'
import Html5QrcodeScanner from 'html5-qrcode'

interface QRScannerProps {
  onScan: (data: string) => void
  onError?: (error: string) => void
}

export default function QRScanner({ onScan, onError }: QRScannerProps) {
  const scannerRef = useRef<Html5QrcodeScanner | null>(null)
  const [isScanning, setIsScanning] = useState(true)

  useEffect(() => {
    if (!isScanning) return

    const scanner = new Html5QrcodeScanner(
      'qr-reader',
      {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        supportedScanTypes: ['CAMERA'],
      },
      false
    )

    scannerRef.current = scanner

    scanner.render(
      (decodedText) => {
        onScan(decodedText)
        setIsScanning(false)
      },
      (error) => {
        if (onError && !error.includes('NotFoundException')) {
          onError(error)
        }
      }
    )

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear().catch(() => {})
      }
    }
  }, [isScanning, onScan, onError])

  const handleReset = () => {
    setIsScanning(true)
  }

  return (
    <div className="space-y-4">
      <div
        id="qr-reader"
        className="w-full max-w-md mx-auto rounded-2xl overflow-hidden border-4 border-[#FFC107]"
      />
      {!isScanning && (
        <button
          onClick={handleReset}
          className="w-full bg-[#001F3F] text-white py-2 rounded-lg font-semibold hover:opacity-90"
        >
          Scan Another ID
        </button>
      )}
    </div>
  )
}
```

### 3.7 app/dashboard/admin/scanner/page.tsx

```typescript
'use client'

import { useState } from 'react'
import QRScanner from '@/components/scanner/QRScanner'
import { supabase, Student } from '@/lib/supabase'

export default function ScannerPage() {
  const [scannedStudent, setScannedStudent] = useState<Student | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [successMessage, setSuccessMessage] = useState('')

  const handleQRScan = async (qrData: string) => {
    setLoading(true)
    setError('')

    try {
      const data = JSON.parse(qrData)
      
      // Fetch student from DB
      const { data: student, error: err } = await supabase
        .from('students')
        .select('*')
        .eq('id_number', data.idNumber)
        .single()

      if (err) throw err

      setScannedStudent(student)
    } catch (err) {
      setError('Invalid QR code or student not found')
    } finally {
      setLoading(false)
    }
  }

  const markAttendance = async (status: 'present' | 'absent') => {
    if (!scannedStudent) return

    setLoading(true)
    try {
      const { error } = await supabase.from('attendance').insert({
        student_id: scannedStudent.id,
        attendance_date: new Date().toISOString().split('T')[0],
        check_in_time: new Date().toISOString(),
        status,
        marked_by: localStorage.getItem('iiecs_admin_id'),
      })

      if (error) throw error

      setSuccessMessage(`${scannedStudent.full_name} marked as ${status}`)
      setScannedStudent(null)
    } catch (err) {
      setError('Failed to mark attendance')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-[#001F3F]">QR Scanner</h1>

      <div className="bg-white rounded-2xl shadow-lg p-6">
        <QRScanner onScan={handleQRScan} onError={setError} />
      </div>

      {scannedStudent && (
        <div className="bg-[#E8F4F8] border-2 border-[#001F3F] rounded-2xl p-6">
          <div className="flex gap-6 mb-6">
            {scannedStudent.profile_photo_url && (
              <img
                src={scannedStudent.profile_photo_url}
                alt={scannedStudent.full_name}
                className="w-24 h-24 rounded-xl object-cover"
              />
            )}
            <div>
              <h2 className="text-2xl font-bold text-[#001F3F]">
                {scannedStudent.full_name}
              </h2>
              <p className="text-gray-600">ID: {scannedStudent.id_number}</p>
              <p className="text-gray-600">{scannedStudent.batch}</p>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={() => markAttendance('present')}
              disabled={loading}
              className="flex-1 bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-green-600"
            >
              Mark Present
            </button>
            <button
              onClick={() => markAttendance('absent')}
              disabled={loading}
              className="flex-1 bg-red-500 text-white py-3 rounded-lg font-semibold hover:bg-red-600"
            >
              Mark Absent
            </button>
          </div>
        </div>
      )}

      {successMessage && (
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">
          ✓ {successMessage}
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          ✗ {error}
        </div>
      )}
    </div>
  )
}
```

### 3.8 app/dashboard/student/page.tsx

```typescript
'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase, Student, Attendance, Invoice, Payment } from '@/lib/supabase'

export default function StudentDashboard() {
  const router = useRouter()
  const [student, setStudent] = useState<Student | null>(null)
  const [attendance, setAttendance] = useState<Attendance[]>([])
  const [payments, setPayments] = useState<Payment[]>([])
  const [activeTab, setActiveTab] = useState<'profile' | 'attendance' | 'payments'>('profile')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const email = localStorage.getItem('iiecs_email')
    if (!email) {
      router.push('/login')
      return
    }

    loadStudentData(email)
  }, [router])

  const loadStudentData = async (email: string) => {
    try {
      // Fetch student
      const { data: studentData, error: studentError } = await supabase
        .from('students')
        .select('*')
        .eq('email', email)
        .single()

      if (studentError) throw studentError

      setStudent(studentData)

      // Fetch attendance
      const { data: attendanceData, error: attendanceError } = await supabase
        .from('attendance')
        .select('*')
        .eq('student_id', studentData.id)
        .order('attendance_date', { ascending: false })

      if (!attendanceError) setAttendance(attendanceData || [])

      // Fetch payments
      const { data: paymentsData, error: paymentsError } = await supabase
        .from('payments')
        .select('*')
        .eq('student_id', studentData.id)

      if (!paymentsError) setPayments(paymentsData || [])
    } catch (err) {
      console.error('Error loading student data:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="text-center py-12">Loading...</div>
  }

  if (!student) {
    return <div className="text-center py-12">Student data not found</div>
  }

  const attendancePercentage = attendance.length > 0
    ? Math.round((attendance.filter(a => a.status === 'present').length / attendance.length) * 100)
    : 0

  const totalDue = payments.filter(p => p.status !== 'paid').reduce((sum, p) => sum + p.amount, 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#001F3F] to-[#003366] text-white rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">{student.full_name}</h1>
            <p className="text-white/80">{student.batch}</p>
          </div>
          <div className="text-right">
            <p className="text-4xl font-bold text-[#FFC107]">{attendancePercentage}%</p>
            <p className="text-white/80">Attendance</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 border-b">
        {(['profile', 'attendance', 'payments'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 font-semibold border-b-2 transition ${
              activeTab === tab
                ? 'border-[#001F3F] text-[#001F3F]'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-2xl shadow-lg p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-600 text-sm">Student ID</p>
              <p className="text-lg font-semibold">{student.id_number}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Email</p>
              <p className="text-lg font-semibold">{student.email}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Phone</p>
              <p className="text-lg font-semibold">{student.phone || 'N/A'}</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm">Enrollment Date</p>
              <p className="text-lg font-semibold">{new Date(student.enrollment_date).toLocaleDateString()}</p>
            </div>
          </div>

          <button className="w-full bg-[#001F3F] text-white py-2 rounded-lg font-semibold hover:opacity-90">
            Download ID Card (PDF)
          </button>
        </div>
      )}

      {activeTab === 'attendance' && (
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="space-y-4">
            {attendance.slice(0, 10).map(record => (
              <div key={record.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-semibold">{new Date(record.attendance_date).toLocaleDateString()}</p>
                  <p className="text-sm text-gray-600">{new Date(record.check_in_time).toLocaleTimeString()}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-white text-sm font-semibold ${
                  record.status === 'present' ? 'bg-green-500' : 'bg-red-500'
                }`}>
                  {record.status.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'payments' && (
        <div className="space-y-4">
          {totalDue > 0 && (
            <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-6">
              <p className="text-gray-600 text-sm">Total Due</p>
              <p className="text-3xl font-bold text-red-600">Rs. {totalDue.toFixed(2)}</p>
            </div>
          )}

          {payments.map(payment => (
            <div key={payment.id} className="bg-white rounded-2xl shadow-lg p-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-semibold">Rs. {payment.amount.toFixed(2)}</p>
                  <p className="text-sm text-gray-600">Due: {payment.due_date}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-white text-sm font-semibold ${
                  payment.status === 'paid' ? 'bg-green-500' : 'bg-yellow-500'
                }`}>
                  {payment.status.toUpperCase()}
                </span>
              </div>
              <button className="mt-4 w-full bg-[#001F3F] text-white py-2 rounded-lg font-semibold hover:opacity-90">
                Download Invoice
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
```

---

## 4. SETUP & DEPLOYMENT

### Local Development

```bash
# 1. Clone and install
git clone <your-repo>
cd iiecs-101-system
npm install

# 2. Install dependencies
npm install @supabase/supabase-js html5-qrcode qrcode jspdf

# 3. Setup Supabase
# - Create account at supabase.com
# - Create new project
# - Run SQL schema from section 1 in SQL Editor
# - Copy credentials to .env.local

# 4. Run development server
npm run dev

# Open http://localhost:3000
```

### Supabase Setup Checklist

- [ ] Create project
- [ ] Run SQL schema in SQL Editor
- [ ] Enable Email authentication (if using)
- [ ] Create storage bucket for PDFs and photos
- [ ] Set up email templates
- [ ] Configure RLS policies:
  ```sql
  ALTER TABLE students ENABLE ROW LEVEL SECURITY;
  ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
  ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
  ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
  
  -- Students can only view their own data
  CREATE POLICY "Students view own data" ON students
    FOR SELECT USING (email = auth.email());
  
  -- Admins can view all data
  CREATE POLICY "Admins view all" ON students
    FOR ALL USING (auth.email() = ANY(string_to_array('admin@iiecs.edu,teacher@iiecs.edu', ',')));
  ```

### Deployment (Vercel)

```bash
# 1. Push to GitHub
git push origin main

# 2. Import to Vercel
# - vercel.com → Import Project → Select repo
# - Add environment variables from .env.local
# - Deploy

# 3. Update Supabase domain allowlist
# Settings → Authentication → Authorized URLs → Add vercel domain
```

---

## 5. API ENDPOINTS REFERENCE

| Endpoint | Method | Auth | Purpose |
|----------|--------|------|---------|
| `/api/auth/login` | POST | - | Login user |
| `/api/attendance/scan` | POST | Admin | Validate QR code |
| `/api/attendance/mark` | POST | Admin | Mark attendance |
| `/api/students/[id]` | GET | Student/Admin | Get student profile |
| `/api/invoices/generate` | POST | Admin | Generate invoice |
| `/api/invoices/download` | GET | Student/Admin | Download invoice PDF |
| `/api/payments/update` | PATCH | Admin | Update payment status |

---

## 6. FEATURES ROADMAP

**Phase 1 (MVP)**
- ✅ Email login
- ✅ QR scanning
- ✅ Attendance marking
- ✅ Student profile
- ✅ Invoice generation

**Phase 2**
- [ ] WhatsApp integration for notifications
- [ ] SMS alerts for dues
- [ ] Batch reports & analytics
- [ ] Automated invoice generation
- [ ] Payment gateway integration

**Phase 3**
- [ ] Mobile app (React Native)
- [ ] Advanced analytics dashboard
- [ ] Parent portal
- [ ] Integration with ScopeIQ for scope tracking

---

## 7. TESTING DATA

Generate test students in Supabase:

```sql
INSERT INTO students (email, full_name, id_number, batch, qr_code_data, status) VALUES
('safi@student.iiecs.edu', 'Safi ullah Abbasi Asif', 'IIECS-014', 'Batch B - C/C++ Algorithms', 
 '{"id":"1","name":"Safi ullah Abbasi Asif","email":"safi@student.iiecs.edu","idNumber":"IIECS-014","batch":"Batch B","enrollmentDate":"2024-01-15"}', 'active'),
('student2@student.iiecs.edu', 'Test Student 2', 'IIECS-015', 'Batch B - C/C++ Algorithms', 
 '{"id":"2","name":"Test Student 2","email":"student2@student.iiecs.edu","idNumber":"IIECS-015","batch":"Batch B","enrollmentDate":"2024-01-15"}', 'active');

INSERT INTO admins (email, full_name, role) VALUES
('admin@iiecs.edu', 'System Admin', 'admin'),
('teacher@iiecs.edu', 'Course Instructor', 'admin');
```

---

## Quick Start Checklist

- [ ] Supabase project created & schema deployed
- [ ] Environment variables configured
- [ ] Dependencies installed
- [ ] Local dev server running
- [ ] Login page working
- [ ] Admin QR scanner functional
- [ ] Student dashboard displaying
- [ ] PDF generation tested
- [ ] Deployed to Vercel
- [ ] Domain configured

---

**Ready to customize.** Modify colors, fonts, and copy to match your exact IIECS branding!
